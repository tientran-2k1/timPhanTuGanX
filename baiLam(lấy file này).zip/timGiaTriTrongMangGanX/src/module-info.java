/**
 * 
 */
/**
 * 
 */
module timGiaTriTrongMangGanX {
}