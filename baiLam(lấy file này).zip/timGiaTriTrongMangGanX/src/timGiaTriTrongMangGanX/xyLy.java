package timGiaTriTrongMangGanX;

import java.util.Scanner;

public class xyLy {

	public xyLy() {
		// TODO Auto-generated constructor stub
	}
	public static int nhapMang(Scanner nhap) {
		int n;
		do {
			System.out.print("Nhập số lượng phần tử: ");
			n = Integer.parseInt(nhap.nextLine());
		} while (n <= 0);
		return n;
	}
	public static float[] taoMang(Scanner nhap, int n) {
		float a[] = new float[n];
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "]=");
			a[i] = Float.parseFloat(nhap.nextLine());
	}
		return a;
	}
	public static void xuatMang(float a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]=" + a[i]+"  ");
		}
		System.out.println();
		}
	
	public static void khoangCachNhoNhat(Scanner nhap, float a[]) {
		float khoangCachNhoNhat = 0;
		float khoangCachDauTien = 0;
		System.out.print("Vui lòng nhập số x: ");
		float x = Float.parseFloat(nhap.nextLine());
		for (int i= 0; i < a.length; i++) {
			khoangCachDauTien = Math.abs(a[i] - x);
			break;
			}
		for (int m= 1; m < a.length; m++) {
			khoangCachNhoNhat = Math.abs(a[m] - x);
			if (khoangCachNhoNhat > khoangCachDauTien) {
				khoangCachNhoNhat = khoangCachDauTien;
			} else {
				khoangCachDauTien = khoangCachNhoNhat;
			}
		}
	
		for (int u = 0; u < a.length; u++) {
			if (khoangCachNhoNhat == Math.abs(a[u] - x)) {
				System.out.print("a[" + u + "]=" + a[u]);
			}
		}
	}

	public static void main(String[] args) {
		Scanner nhap = new Scanner(System.in);
		int n = nhapMang(nhap);
		float a[] = taoMang(nhap, n);
		xuatMang(a);
		khoangCachNhoNhat(nhap, a);
		
			

	}

}
