package timGiaTriTrongMangGanX;

import java.util.Scanner;

public class xyLy {

	public xyLy() {
		// TODO Auto-generated constructor stub
	}
	public static int nhapMang(Scanner nhap) {
		int n;
		do {
			System.out.print("Nhập số lượng phần tử: ");
			n = Integer.parseInt(nhap.nextLine());
		} while (n <= 0);
		return n;
	}
	public static float[] taoMang(Scanner nhap, int n) {
		float a[] = new float[n];
		for (int i = 0; i < n; i++) {
			System.out.print("a[" + i + "]=");
			a[i] = Float.parseFloat(nhap.nextLine());
	}
		return a;
	}
	public static void xuatMang(float a[]) {
		for (int i = 0; i < a.length; i++) {
			System.out.print("a[" + i + "]=" + a[i]+"  ");
		}
		System.out.println();
		}
	public static void khoangCachNhoNhat(Scanner nhap, float a[]) {
		float khoangCach = 0;
		float khoangCachNhoNhat = 0;
		System.out.print("Vui lòng nhập số x: ");
		float x = Integer.parseInt(nhap.nextLine());
		for (int i= 0; i < a.length; i++) {
			khoangCach = Math.abs(a[i] - x);
			if ((khoangCachNhoNhat == 0) || (khoangCachNhoNhat > khoangCach)) {
				khoangCachNhoNhat = khoangCach;
		}
	}	
		System.out.println("Các phần tử gần với " + x + " là: ");
		for (int j = 0; j < a.length; j++) {
			float khoangCachl2 =  Math.abs(a[j] - x);
			if (khoangCachNhoNhat == khoangCachl2) {
				System.out.print("a["+j+"]=" + a[j] + "  ");
			}
		}
	}
			
	public static void main(String[] args) {
		Scanner nhap = new Scanner(System.in);
		int n = nhapMang(nhap);
		float a[] = taoMang(nhap, n);
		xuatMang(a);
		khoangCachNhoNhat(nhap, a);
		
			

	}

}
